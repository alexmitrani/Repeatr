## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------
one_row_per_show <- Repeatr1 %>% group_by(gid) %>% slice(1) %>% ungroup()
nrow(one_row_per_show)

## -----------------------------------------------------------------------------
knitr::kable(fugazi_song_counts, "pipe")

## -----------------------------------------------------------------------------
knitr::kable(fugazi_song_performance_intensity, "pipe")

## -----------------------------------------------------------------------------
nrow(Repeatr1)

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[1]], "pipe")

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[3]], "pipe")

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[4]], "pipe")

