params <-
list(output_dir = "../docs")

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
output_dir <- params$output_dir

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------
code_dir <- "vignettes"
code_dir <- file.path("..",code_dir)
index_filename <- "index.Rmd"
index_filename <- file.path(code_dir, index_filename)
output_dir <- "docs"
output_dir <- file.path("..",output_dir)
render(index_filename, output_dir = output_dir, params = list(output_dir = output))

