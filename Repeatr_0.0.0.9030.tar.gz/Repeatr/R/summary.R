#' Summary
#'
#' @source https://www.dischord.com/fugazi_live_series
#' @format dataframe with one row for each song in the Fugazi discography, except those which never appear in the Fugazi Live Series data.
#' \describe{
#' \item{rank_rating}{The rank of the song in terms of the rating derived from the choice modelling, with the highest-rated song in the first position.}
#' \item{songid}{numeric id for each song}
#' \item{song}{The name of the song}
#' \item{launchdate}{The date on which the song was first performed according to the data}
#' \item{duration_seconds}{The duration of the song in seconds}
#' \item{chosen}{The number of times the song was performed according to the data}
#' \item{available_rl}{The number of shows for which the song was available in the band's repertoire}
#' \item{intensity}{The performance intensity is the ratio of chosen/available_rl}
#' \item{rating}{Rating on the interval between 0 and 1 where 1 is the highest rating and 0 the lowest.}
#' \item{releaseid}{numeric id in ascending chronological order}
#' \item{release}{release name}
#' \item{track_number}{The track number for the song on the release}
#' \item{instrumental}{Indicates whether or not the piece is an instrumental}
#' \item{vocals_picciotto}{indicates whether or not Guy Picciotto sang lead vocals on this track}
#' \item{vocals_mackaye}{indicates whether or not Ian Mackaye sang lead vocals on this track}
#' \item{vocals_lally}{indicates whether or not Joe Lally sang lead vocals on this track}
#' }
#' @examples
#'   summary
"summary"
