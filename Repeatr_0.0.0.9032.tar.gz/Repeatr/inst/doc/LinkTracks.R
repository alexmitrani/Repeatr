## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.width=7,
  fig.height=5,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------
mydf <- othervariables %>%
  filter(is.na(attendance)==FALSE)

maxattendance <- max(mydf$attendance)

maxattendance

mydf %>%
  filter(attendance == maxattendance)

