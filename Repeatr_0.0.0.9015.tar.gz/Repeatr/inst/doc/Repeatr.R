## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------
one_row_per_show <- Repeatr1 %>% group_by(gid) %>% slice(1) %>% ungroup()
nrow(one_row_per_show)

## -----------------------------------------------------------------------------
knitr::kable(fugazi_song_counts, "pipe")

## -----------------------------------------------------------------------------
knitr::kable(fugazi_song_performance_intensity, "pipe")

## -----------------------------------------------------------------------------
nrow(Repeatr1)

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[1]], "pipe")

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[3]], "pipe")

## ----echo=T, results='hide'---------------------------------------------------
songstobecompared <- summary %>% slice(seq(from=1, to=10, by=1))
mycomparisons <- rankr(mymodel = ml.Repeatr4, mysongidlist = songstobecompared)
mycomparisons <- mycomparisons %>%
  select(song1, song2, mycoef1, mycoef2, mycoefdiff, myz) %>%
  rename(coef1 = mycoef1, coef2 = mycoef2, coefdiff = mycoefdiff, z = myz)

## -----------------------------------------------------------------------------
knitr::kable(mycomparisons, format = "pipe")

## ----echo=T, results='hide'---------------------------------------------------
songstobecompared <- summary %>% slice(seq(from=1, to=92, by=8))
mycomparisons <- rankr(mymodel = ml.Repeatr4, mysongidlist = songstobecompared)
mycomparisons <- mycomparisons %>%
  select(song1, song2, mycoef1, mycoef2, mycoefdiff, myz) %>%
  rename(coef1 = mycoef1, coef2 = mycoef2, coefdiff = mycoefdiff, z = myz)

## -----------------------------------------------------------------------------
knitr::kable(mycomparisons, format = "pipe")

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[4]], "pipe")

