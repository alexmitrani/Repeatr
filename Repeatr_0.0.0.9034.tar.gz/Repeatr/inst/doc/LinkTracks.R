## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.width=7,
  fig.height=5,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------
mydf <- othervariables %>%
  filter(is.na(attendance)==FALSE)

maxattendance <- max(mydf$attendance)

maxattendance

mydf %>%
  filter(attendance == maxattendance)

## -----------------------------------------------------------------------------

medianattendance <- othervariables %>%
  filter(is.na(attendance)==FALSE) %>%
  group_by(tour) %>%
  summarise(medianattendance = median(attendance)) %>%
  ungroup()

mydf <- othervariables %>%
  left_join(medianattendance) %>%
  mutate(attendance = ifelse(is.na(attendance)==TRUE,medianattendance,attendance)) %>%
  group_by(tour) %>%
  summarise(start = min(date), end = max(date), shows = n(), duration = as.numeric((end - start)), attendance=sum(attendance)) %>%
  ungroup() %>%
  arrange(desc(shows))

head(mydf, n=10)
  

## -----------------------------------------------------------------------------

mydf <- othervariables %>% group_by(tour, country) %>% summarise(shows = n()) %>% ungroup()

mydf2 <- mydf %>% filter(tour=="1990 Fall European Tour" | tour == "1995 Spring/Summer European Tour") %>% pivot_wider(names_from = tour, values_from = shows)

mydf2[is.na(mydf2)] <- 0

mydf2

## -----------------------------------------------------------------------------
releasedates <- releasesdatalookup %>% 
  select(releaseid, releasedate) %>%
  mutate(releasedate = as.Date(releasedate, "%d/%m/%Y"))

mydf <- songvarslookup %>% 
  left_join(releasedates) %>%
  left_join(songidlookup)
mydf <- mydf %>% 
  select(songid, song, releaseid, releasedate) %>%
  arrange(songid)
head(mydf)


## -----------------------------------------------------------------------------
mysummary <- Repeatr::summary %>% 
  left_join(mydf) %>%
  mutate(lead = releasedate - launchdate) %>%
  select(song, launchdate, releasedate, lead) %>%
  arrange(lead)

head(mysummary, n = 10)

## -----------------------------------------------------------------------------
mean(mysummary$lead)

## -----------------------------------------------------------------------------
mysummary <- mysummary %>%
  select(song, launchdate, releasedate, lead) %>%
  arrange(desc(lead))

head(mysummary, n = 10)

## -----------------------------------------------------------------------------
median(mysummary$lead)

