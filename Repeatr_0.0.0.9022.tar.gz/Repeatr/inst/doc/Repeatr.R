## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------
one_row_per_show <- Repeatr1 %>% group_by(gid) %>% slice(1) %>% ungroup()
nrow(one_row_per_show)

## -----------------------------------------------------------------------------
knitr::kable(fugazi_song_counts, "pipe")

## -----------------------------------------------------------------------------
knitr::kable(fugazi_song_performance_intensity, "pipe")

## -----------------------------------------------------------------------------
nrow(Repeatr1)

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
myresults <- as.data.frame(Repeatr_5_results[1]) %>%
  arrange(desc(Estimate))
knitr::kable((myresults), "pipe")

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[3]], "pipe")

## ----echo=T, results='hide'---------------------------------------------------
songstobecompared <- Repeatr_5_results[[3]] %>% slice(seq(from=1, to=2, by=1))
mycomparisons <- rankr(mymodel = ml.Repeatr4, mysongidlist = songstobecompared)
mycomparisons <- mycomparisons %>%
  select(song1, song2, mycoef1, mycoef2, mycoefdiff, myz) %>%
  rename(coef1 = mycoef1, coef2 = mycoef2, coefdiff = mycoefdiff, z = myz)

## -----------------------------------------------------------------------------
knitr::kable(mycomparisons, format = "pipe", digits = 3)

## ----echo=T, results='hide'---------------------------------------------------
songstobecompared <- Repeatr_5_results[[3]] %>% slice(seq(from=1, to=92, by=8))
mycomparisons <- rankr(mymodel = ml.Repeatr4, mysongidlist = songstobecompared)
mycomparisons <- mycomparisons %>%
  select(song1, song2, mycoef1, mycoef2, mycoefdiff, myz) %>%
  rename(coef1 = mycoef1, coef2 = mycoef2, coefdiff = mycoefdiff, z = myz)

## -----------------------------------------------------------------------------
knitr::kable(mycomparisons, format = "pipe", digits = 3)

## -----------------------------------------------------------------------------
Repeatr_5_results <- Repeatr_5(mymodel = ml.Repeatr4)
knitr::kable(Repeatr_5_results[[4]], "pipe")

