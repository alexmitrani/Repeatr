## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------
mygraphdata <- summary %>%
  left_join(songvarslookup)

mygraphdata <- mygraphdata %>%
  select(song, launchdate, chosen, release, rating)

knitr::kable(mygraphdata, "pipe")


## -----------------------------------------------------------------------------

p <- mygraphdata %>%
  ggplot( aes(x=launchdate, y=rating, size = chosen, color=release, label=song)) +
  geom_point(shape = 1) +
  theme_bw()

ggplotly(p)



