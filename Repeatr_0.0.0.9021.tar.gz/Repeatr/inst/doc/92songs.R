## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.width=7,
  fig.height=5,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------

mygraphdata <- summary %>%
  select(song, launchdate, chosen, release, rating)

head(mygraphdata)


## -----------------------------------------------------------------------------

p <- mygraphdata %>%
  ggplot( aes(x=launchdate, y=rating, size = chosen, color=release, label=song)) +
  geom_point(shape = 1) +
  theme_bw()

ggplotly(p)



