## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.width=7,
  fig.height=5,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------

mydf1 <- Repeatr1 %>%
  select(gid,song_number,song) %>%
  rename(song1 = song)

print(paste0("There are ", nrow(mydf1), " rows in this dataframe."))

head(mydf1)


## -----------------------------------------------------------------------------

mydf2 <- Repeatr1 %>%
  select(gid,song_number,song) %>%
  mutate(song_number = song_number-1) %>%
  rename(song2 = song)

mydf3 <- mydf1 %>%
  left_join(mydf2) %>%
  filter(is.na(song2)==FALSE) %>%
  rename(transition_number = song_number)

print(paste0("There are ", nrow(mydf3), " rows in this dataframe."))

head(mydf3)



## -----------------------------------------------------------------------------

checknumberofshows <- Repeatr1 %>%
  group_by(gid) %>%
  summarise(songs = n()) %>%
  ungroup()

numberofshows <- nrow(checknumberofshows)

print(paste0("There are ", numberofshows, " rows in this dataframe."))

head(checknumberofshows)

numberofsongs <- sum(checknumberofshows$songs)

numberoftransitions <- numberofsongs - numberofshows

print(paste0("There are ", numberofsongs, " songs, ", numberofshows, " shows, and ", numberoftransitions, " transitions between songs in the Fugazi Live Series data."  ))


## -----------------------------------------------------------------------------

transitions <- mydf3 %>%
  select(song1, song2) %>%
  rename(from = song1) %>%
  rename(to = song2)

transitions <- transitions %>%
  group_by(from, to) %>%
  summarize(count = n()) %>%
  ungroup()

transitions <- transitions %>%
  arrange(desc(count))

head(transitions)



## -----------------------------------------------------------------------------

transitions$song <- transitions$from

mylookup <- fugazi_song_performance_intensity %>%
  select(song, available_rl)

transitions <- transitions %>%
  left_join(mylookup) %>%
  rename(from_available_rl = available_rl)

transitions$song <- transitions$to

transitions <- transitions %>%
  left_join(mylookup) %>%
  rename(to_available_rl = available_rl) %>%
  mutate(available_rl = ifelse(from_available_rl < to_available_rl, from_available_rl, to_available_rl)) %>%
  mutate(count_scaled = count/available_rl) %>%
  select(from, to, from_available_rl, to_available_rl, available_rl, count, count_scaled) %>%
  arrange(desc(count_scaled))

head(transitions)

transitions <- transitions %>%
  select(from, to, count_scaled)


## -----------------------------------------------------------------------------

launchdateindex_from <- fugazi_song_counts %>%
  arrange(launchdate) %>%
  mutate(launchdateindex_from = row_number()) %>%
  rename(from = song) %>%
  select(from, launchdateindex_from)

launchdateindex_to <- launchdateindex_from %>%
  rename(to = from, launchdateindex_to = launchdateindex_from)

transitions <- transitions %>%
  left_join(launchdateindex_from) %>%
  left_join(launchdateindex_to) %>%
  arrange(launchdateindex_from, launchdateindex_to) %>%
  mutate(to = paste0("to_", sprintf("%02d", launchdateindex_to), "_", to)) %>%
  mutate(from = paste0("from_", sprintf("%02d", launchdateindex_from), "_", from)) %>%
  select(from, to, count_scaled)

heatmapdata <- pivot_wider(transitions, names_from = to, values_from = count_scaled, names_sort=TRUE)

heatmapdata[is.na(heatmapdata)] <- 0

heatmapdata <- heatmapdata %>%
  arrange(desc(from))
heatmapdata <- data.frame(heatmapdata, row.names = 1)
heatmapdata <- heatmapdata[ , order(names(heatmapdata))]
heatmapdata <- as.matrix(heatmapdata)

heatmaply(
  as.matrix(heatmapdata),
  seriate="none",
  Rowv=FALSE,
  Colv=FALSE,
  show_dendrogram=FALSE,
  plot_method = "plotly"
)



