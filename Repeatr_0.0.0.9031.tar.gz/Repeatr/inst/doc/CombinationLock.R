## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.width=7,
  fig.height=5,
  comment = "#>"
)

## ---- include = FALSE---------------------------------------------------------
library(Repeatr)

## -----------------------------------------------------------------------------

mydf1 <- Repeatr1 %>%
  select(gid,song_number,song) %>%
  rename(song1 = song)

print(paste0("There are ", nrow(mydf1), " rows in this dataframe."))

head(mydf1)


## -----------------------------------------------------------------------------

mydf2 <- Repeatr1 %>%
  select(gid,song_number,song) %>%
  mutate(song_number = song_number-1) %>%
  rename(song2 = song)

mydf3 <- mydf1 %>%
  left_join(mydf2) %>%
  filter(is.na(song2)==FALSE) %>%
  rename(transition_number = song_number)

print(paste0("There are ", nrow(mydf3), " rows in this dataframe."))

head(mydf3)



## -----------------------------------------------------------------------------

checknumberofshows <- Repeatr1 %>%
  group_by(gid) %>%
  summarise(songs = n()) %>%
  ungroup()

numberofshows <- nrow(checknumberofshows)

print(paste0("There are ", numberofshows, " rows in this dataframe."))

head(checknumberofshows)

numberofsongs <- sum(checknumberofshows$songs)

numberoftransitions <- numberofsongs - numberofshows

print(paste0("There are ", numberofsongs, " songs, ", numberofshows, " shows, and ", numberoftransitions, " transitions between songs in the Fugazi Live Series data."  ))


## -----------------------------------------------------------------------------

transitions <- mydf3 %>%
  select(song1, song2) %>%
  rename(from = song1) %>%
  rename(to = song2)

transitions <- transitions %>%
  group_by(from, to) %>%
  summarize(count = n()) %>%
  ungroup()

transitions <- transitions %>%
  arrange(desc(count))

head(transitions)



## -----------------------------------------------------------------------------

transitions$song <- transitions$from

mylookup <- fugazi_song_performance_intensity %>%
  select(song, available_rl)

transitions <- transitions %>%
  left_join(mylookup) %>%
  rename(from_available_rl = available_rl)

transitions$song <- transitions$to

transitions <- transitions %>%
  left_join(mylookup) %>%
  rename(to_available_rl = available_rl) %>%
  mutate(available_rl = ifelse(from_available_rl < to_available_rl, from_available_rl, to_available_rl)) %>%
  mutate(count_scaled = count/available_rl) %>%
  select(from, to, from_available_rl, to_available_rl, available_rl, count, count_scaled) %>%
  arrange(desc(count_scaled))

head(transitions)

transitions <- transitions %>%
  select(from, to, count, count_scaled)


## -----------------------------------------------------------------------------

launchdateindex_from <- fugazi_song_counts %>%
  arrange(launchdate) %>%
  mutate(launchdateindex_from = row_number()) %>%
  rename(from = song) %>%
  select(from, launchdateindex_from)

launchdateindex_to <- launchdateindex_from %>%
  rename(to = from, launchdateindex_to = launchdateindex_from)

transitions2 <- transitions %>%
  left_join(launchdateindex_from) %>%
  left_join(launchdateindex_to) %>%
  arrange(launchdateindex_from, launchdateindex_to) %>%
  mutate(to = paste0("to_", sprintf("%02d", launchdateindex_to), "_", to)) %>%
  mutate(from = paste0("from_", sprintf("%02d", launchdateindex_from), "_", from)) %>%
  select(from, to, count_scaled)

heatmapdata <- pivot_wider(transitions2, names_from = to, values_from = count_scaled, names_sort=TRUE)

heatmapdata[is.na(heatmapdata)] <- 0

heatmapdata <- heatmapdata %>%
  arrange(desc(from))
heatmapdata <- data.frame(heatmapdata, row.names = 1)
heatmapdata <- heatmapdata[ , order(names(heatmapdata))]
heatmapdata <- as.matrix(heatmapdata)

heatmaply(
  as.matrix(heatmapdata),
  seriate="none",
  Rowv=FALSE,
  Colv=FALSE,
  show_dendrogram=FALSE,
  plot_method = "plotly"
)



## -----------------------------------------------------------------------------

mysongvarslookup <- songvarslookup %>%
  left_join(songidlookup)

mysongvarslookup <- mysongvarslookup %>%
  mutate(vocals = ifelse(vocals_lally==1,"lally",0)) %>%
  mutate(vocals = ifelse(vocals_mackaye==1,"mackaye",vocals)) %>%
  mutate(vocals = ifelse(vocals_picciotto==1,"picciotto",vocals)) %>%
  mutate(vocals = ifelse(instrumental==1,"instrumental",vocals)) %>%
  select(song, vocals)

head(mysongvarslookup)

checkvocals <- mysongvarslookup %>%
  group_by(vocals) %>%
  summarise(count = n()) %>%
  ungroup() %>%
  arrange(desc(count)) %>%
  mutate(group = row_number())

checkvocals


## -----------------------------------------------------------------------------

mysongvarslookup1 <- mysongvarslookup %>% rename(from = song, from_vocals = vocals)

mysongvarslookup2 <- mysongvarslookup %>% rename(to = song, to_vocals = vocals)

transitions3 <- transitions %>%
  left_join(mysongvarslookup1) %>%
  left_join(mysongvarslookup2) %>%
  select(from, to, from_vocals, to_vocals, count)

totaltransitions <- sum(transitions$count)

transitions_by_group <- transitions3 %>%
  group_by(from_vocals, to_vocals) %>%
  summarise(count = sum(count)) %>%
  ungroup() %>%
  arrange(desc(count)) %>%
  mutate(proportion = round((count / totaltransitions), digits = 2))

transitions_by_group


## -----------------------------------------------------------------------------

transitions4 <- transitions %>%
  left_join(mysongvarslookup1) %>%
  left_join(mysongvarslookup2) %>%
  select(from, to, from_vocals, to_vocals, count_scaled)

checkvocals_from <- checkvocals %>%
  select(vocals, group) %>%
  rename(from_vocals = vocals, from_group = group)

checkvocals_to <- checkvocals %>%
  select(vocals, group) %>%
  rename(to_vocals = vocals, to_group = group)

launchdateindex_from <- fugazi_song_counts %>%
  arrange(launchdate) %>%
  mutate(launchdateindex_from = row_number()) %>%
  rename(from = song) %>%
  select(from, launchdateindex_from)

launchdateindex_to <- launchdateindex_from %>%
  rename(to = from, launchdateindex_to = launchdateindex_from)

transitions5 <- transitions4 %>%
  left_join(launchdateindex_from) %>%
  left_join(launchdateindex_to) %>%
  left_join(checkvocals_from) %>%
  left_join(checkvocals_to) %>%
  mutate(index_from=from_group*100+launchdateindex_from) %>%
  mutate(index_to=to_group*100+launchdateindex_to) %>%
  arrange(index_from, index_to) %>%
  mutate(to = paste0("to_", sprintf("%03d", index_to), "_", to)) %>%
  mutate(from = paste0("from_", sprintf("%03d", index_from), "_", from)) %>%
  select(from, to, count_scaled)

heatmapdata <- pivot_wider(transitions5, names_from = to, values_from = count_scaled, names_sort=TRUE)

heatmapdata[is.na(heatmapdata)] <- 0

heatmapdata <- heatmapdata %>%
  arrange(desc(from))
heatmapdata <- data.frame(heatmapdata, row.names = 1)
heatmapdata <- heatmapdata[ , order(names(heatmapdata))]
heatmapdata <- as.matrix(heatmapdata)

heatmaply(
  as.matrix(heatmapdata),
  seriate="none",
  Rowv=FALSE,
  Colv=FALSE,
  show_dendrogram=FALSE,
  plot_method = "plotly"
)


